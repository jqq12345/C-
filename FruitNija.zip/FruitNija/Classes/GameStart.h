#ifndef _gamestart_
#define _gamestart_
#include "cocos2d.h"
#include "FruitManager.h"
#include "SimpleAudioEngine.h"
using namespace cocos2d;
USING_NS_CC;
class GameStart: public CCLayer
{
public :
	GameStart();
	static CCScene* scene();
	virtual bool init();
	CREATE_FUNC(GameStart);
	virtual bool ccTouchBegan(CCTouch *pTouches, CCEvent *pEvent);
	virtual void ccTouchMoved(CCTouch *pTouches, CCEvent *pEvent);
	virtual void ccTouchEnded(CCTouch *pTouches, CCEvent *pEvent);

    //CCPoint getPoint();
    //CCPoint point;
	float ang;

	CCSize size;
	void keyBackClicked();

	//void  addfruit(float dt);

	CCPoint _point[2];
	int index;


	FruitManager* fruitmanager;
	CCParticleSystemQuad* knifecolor;  //����Ч��
	CCMotionStreak* streak;            //��βЧ��


};
#endif